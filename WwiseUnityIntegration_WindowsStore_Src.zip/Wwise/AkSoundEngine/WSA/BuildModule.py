# WSA Wwise Unity Build module
import BuildUtil
import BuildWwiseUnityIntegration
import GenerateApiBinding
from os import path
from BuildWwiseUnityIntegration import MultiArchBuilder
from GenerateApiBinding import SwigCommand
from PrepareSwigInput import SwigPlatformHandler, SwigApiHeaderBlobber, PlatformStructProfile

class WSABuilder(MultiArchBuilder):
	def __init__(self, platformName, arches, configs, generateSwig, generatePremake):
		MultiArchBuilder.__init__(self, platformName, arches, configs, generateSwig, generatePremake)

		self._FindMSBuildPath()

		pathMan = BuildUtil.PathManager(self.platformName)
		self.solution = path.join(pathMan.Paths['Src_Platform'], '{}WSA.sln'.format(pathMan.ProductName))

	def _CreateCommands(self, arch=None, config='Profile'):
		# Edit name back to Visual Studio arch name.
		if arch in BuildUtil.SupportedArches['WSA']:
			prefix = 'WSA_'
			arch = arch[len(prefix):]
			arch = arch.replace('WindowsPhone81_', '')
			arch = arch.replace('UWP_', '')
		else:
			msg = 'Undefined architecture: {}, available options: {}'.format(arch, ', '.join(BuildUtil.SupportedArches['WSA']))
			self.logger.error(msg)
			raise RuntimeError(msg)
		
		cmds = []
		for t in self.tasks:
			cmd = ['{}'.format(self.compiler), '{}'.format(self.solution), '/t:{}'.format(t), '/p:Configuration={};Platform={}'.format(config, arch)]
			cmds.append(cmd)
		return cmds

class WSAUWPWin32SwigCommand(SwigCommand):
	def __init__(self, pathMan):
		SwigCommand.__init__(self, pathMan)

		self.platformDefines = ['-DAK_WSA', '-DWINAPI_FAMILY', '-DWIN32', '-DAK_USE_WSA_API', '-DAK_WIN_UNIVERSAL_APP', '-DAK_WIN']

class WSAUWPARMSwigCommand(SwigCommand):
	def __init__(self, pathMan):
		SwigCommand.__init__(self, pathMan)

		self.platformDefines = ['-DAK_WSA', '-DWINAPI_FAMILY', '-D_M_ARM', '-D_ARM_WINAPI_PARTITION_DESKTOP_SDK_AVAILABLE=1', '-DAK_USE_WSA_API', '-DAK_WIN_UNIVERSAL_APP', '-DAK_WIN']

class WSAUWPX64SwigCommand(SwigCommand):
	def __init__(self, pathMan):
		SwigCommand.__init__(self, pathMan)

		self.platformDefines = ['-DAK_WSA', '-DWINAPI_FAMILY', '-DX64', '-DAK_USE_WSA_API', '-DAK_WIN_UNIVERSAL_APP', '-DAK_WIN']

class WSAUWPARM64SwigCommand(SwigCommand):
	def __init__(self, pathMan):
		SwigCommand.__init__(self, pathMan)

		self.platformDefines = ['-DAK_WSA', '-DWINAPI_FAMILY', '-D_M_ARM64', '-D_ARM_WINAPI_PARTITION_DESKTOP_SDK_AVAILABLE=1', '-DAK_USE_WSA_API', '-DAK_WIN_UNIVERSAL_APP', '-DAK_WIN']

class SwigApiHeaderBlobberWSA(SwigApiHeaderBlobber):
	def __init__(self, pathMan):
		SwigApiHeaderBlobber.__init__(self, pathMan)

		self.inputHeaders.append(path.normpath(path.join(self.SdkIncludeDir, 'AK/SoundEngine/Platforms/Windows/AkWinSoundEngine.h')))

class SwigPlatformHandlerWSA(SwigPlatformHandler):
	def __init__(self, pathMan):
		SwigPlatformHandler.__init__(self, pathMan)

		ThreadPropertyHeader = 'AK/Tools/Win32/AkPlatformFuncs.h'
		self.PlatformStructProfiles += \
		[
			PlatformStructProfile(self.pathMan, ThreadPropertyHeader, SwigPlatformHandler.ThreadPropertiesRegEx)
		]

		self.ioFileSources = \
		[
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], path.normpath('SoundEngine/Win32/AkFileHelpers.h')),
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], path.normpath('SoundEngine/Win32/AkDefaultIOHookBlocking.cpp')),
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], path.normpath('SoundEngine/Win32/AkDefaultIOHookBlocking.h')),
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], path.normpath('SoundEngine/Win32/AkFilePackageLowLevelIOBlocking.h'))
		]

def Init(argv=None):
	BuildUtil.BankPlatforms['WSA'] = 'Windows'
	BuildUtil.SupportedArches['WSA'] = ['WSA_UWP_Win32', 'WSA_UWP_ARM', 'WSA_UWP_x64', 'WSA_UWP_ARM64']
	BuildUtil.PremakeParameters['WSA'] = { 'os': 'uwp', 'generator': 'vs2017' }
	BuildUtil.PlatformSwitches['WSA'] = '#if UNITY_WSA && ! UNITY_EDITOR'
	BuildUtil.PlatformDependentFilenames.append('PROCESSOR_NUMBER.cs')
	BuildUtil.SupportedPlatforms['Windows'].append('WSA')

def CreatePlatformBuilder(platformName, arches, configs, generateSwig, generatePremake):
	return WSABuilder(platformName, arches, configs, generateSwig, generatePremake)

def CreateSwigCommand(pathMan, arch):
	if arch == 'WSA_UWP_Win32':
		return WSAUWPWin32SwigCommand(pathMan)
	elif arch == 'WSA_UWP_ARM':
		return WSAUWPARMSwigCommand(pathMan)
	elif arch == 'WSA_UWP_x64':
		return WSAUWPX64SwigCommand(pathMan)
	elif arch == 'WSA_UWP_ARM64':
		return WSAUWPARM64SwigCommand(pathMan)
	else:
		return None

def CreateSwigPlatformHandler(pathMan):
	return SwigPlatformHandlerWSA(pathMan)

def CreateSwigApiHeaderBlobber(pathMan):
	return SwigApiHeaderBlobberWSA(pathMan)

if __name__ == '__main__':
	pass
